var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rooms/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__08972191._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_rooms_[code]_route_actions_d5368adc.js")
R.m(20078)
module.exports=R.m(20078).exports
