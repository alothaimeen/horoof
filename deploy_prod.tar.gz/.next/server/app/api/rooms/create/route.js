var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rooms/create/route.js")
R.c("server/chunks/[root-of-the-server]__0734929f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_rooms_create_route_actions_b72f6602.js")
R.m(49617)
module.exports=R.m(49617).exports
