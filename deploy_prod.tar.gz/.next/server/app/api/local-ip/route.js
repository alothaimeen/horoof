var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/local-ip/route.js")
R.c("server/chunks/[root-of-the-server]__84e94647._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_local-ip_route_actions_90ea061d.js")
R.m(95869)
module.exports=R.m(95869).exports
