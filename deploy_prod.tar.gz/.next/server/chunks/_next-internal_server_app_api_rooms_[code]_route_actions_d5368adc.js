module.exports=[40334,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rooms_%5Bcode%5D_route_actions_d5368adc.js.map