module.exports=[53367,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_local-ip_route_actions_90ea061d.js.map